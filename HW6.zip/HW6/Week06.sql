-- 1.   Pubs - What authors are in California --15
use pubs
select [au_id]
      ,[au_lname]
      ,[au_fname]
	  ,[state]
from authors
where[state] = 'CA' 

-- 2.   Pubs - List the titles and author names --25
use pubs
select t.title, a.au_fname + ' ' + a.au_lname as Full_Name
from authors as a
inner join titleauthor as b
on a.au_id = b.au_id
inner join titles as t
on b.title_id = t.title_id

 --3.   Pubs - List all employees and their jobs --43
 use pubs
 select e.fname +' ' + e.lname as Full_Name, j.job_desc
from employee as e
inner join jobs as j
on e.job_id = j.job_id

-- 4.   Pubs - List the titles by total sales price --18
use pubs
select t.title, sum(s.qty*t.price) as Total_Sales_Price
from titles as t
left join sales as s
on t.title_id = s.title_id
group by t.title

--5.   Pubs - Find the total sales by store for stores in California --3
use pubs
select a.stor_name, a.state, sum(s.qty*price) as Total_Sales
from titles as t
inner join sales as s
on t.title_id = s.title_id
inner join stores as a
on a.stor_id = s.stor_id
where a.state = 'CA'
group by a.stor_name, a.state

--6.   Pubs - List the store name, title title name and quantity for all stores that have net 30 payterms
use pubs
select a.stor_name, t.title, s.qty, s.payterms
from stores as a
inner join sales as s
on s.stor_id = a.stor_id
inner join titles as t
on t.title_id = s.title_id
where payterms = 'Net 30'

--7.   Pubs - Find the titles that do not have any sales show the name of the title
use pubs
select t.title_id, t.title
from  titles t
where t.title_id not in (select distinct t.title_id from titles as t
                         left join sales as s
						 on t.title_id = s.title_id
						 where s.title_id is not NULL)

--8.   Pubs - Do previous question another way
use pubs
select t.title_id, t.title
from  titles t
where not exists (select distinct s.title_id from sales as s 
                  where s.title_id = t.title_id)
						 
--9.   AdventureWorks - List all the employees show name and department --296	
use AdventureWorks2014					 
select distinct p.firstname + ' ' + p.lastname as name, d.name  as department
from [Person].[Person] as p
inner join [HumanResources].[EmployeeDepartmentHistory]	as e
on e.BusinessEntityID = p.BusinessEntityID
inner join [HumanResources].[Department] as d
on d.DepartmentID = e.DepartmentID	
where  e.enddate is null 

--10.   AdventureWorks - Show the employees and their current and prior departments
use AdventureWorks2014
select	p.firstname + ' ' + p.lastname as name,
case when e.enddate is null then d.name end as current_department,
case when e.enddate is not null then d.name end as prior_demartment	
	from [Person].[Person] as p
inner join [HumanResources].[EmployeeDepartmentHistory]	as e
on e.BusinessEntityID = p.BusinessEntityID
inner join [HumanResources].[Department] as d
on d.DepartmentID = e.DepartmentID

--10. another way
use AdventureWorks2014
select x.name, x.currtent_department, y.privious_department
from
(select p.firstname + ' ' + p.lastname as name, d.name  as currtent_department
from [Person].[Person] as p
inner join [HumanResources].[EmployeeDepartmentHistory]	as e
on e.BusinessEntityID = p.BusinessEntityID
inner join [HumanResources].[Department] as d
on d.DepartmentID = e.DepartmentID	
where  e.enddate is null) as x
left join
(select p.firstname + ' ' + p.lastname as name, d.name  as privious_department
from [Person].[Person] as p
inner join [HumanResources].[EmployeeDepartmentHistory]	as e
on e.BusinessEntityID = p.BusinessEntityID
inner join [HumanResources].[Department] as d
on d.DepartmentID = e.DepartmentID	
where  e.enddate is not null) as y
on x.name = y.name

--11.   AdventureWorks - Break apart the employee login id so that you have the domain (before the /) in one column and the login id (after the /) in two columns
use AdventureWorks2014
select
   loginid,
   SUBSTRING(loginid, 0, CHARINDEX('\',loginid,0)) as domail, 
   SUBSTRING(loginid, CHARINDEX('\',loginid,0)+1, len(loginid)) as login_id
from humanresources.Employee

--12.   AdventureWorks - Build a new column in a copy of the employee table that is the employee email address in the form login_id@domain.com, populate the column 
use AdventureWorks2014
select a.*,SUBSTRING(loginid, CHARINDEX('\',loginid,0)+1, len(loginid)) 
        + '@' + SUBSTRING(loginid, 0, CHARINDEX('\',loginid,0)) 
		+ '.com' as email into emp_table_copy from humanresources.Employee as a
select * from emp_table_copy

--13.   AdventureWorks - Calculate the age of an employee in years - Does it work if the birthday hasn't happened yet if not fix it
use AdventureWorks2014
select p.firstname +' ' + p.lastname as full_name, e.birthdate,
       getdate() as Today,
       datediff(YY, e.birthdate, getdate()) as wrong_age,
	   datediff(YY, e.birthdate, getdate()) - 
	   case when dateadd(YY, datediff(YY, e.birthdate, getdate()), e.birthdate) > getdate() then 1
	   else 0 end as age
from [Person].[Person] as p
inner join [HumanResources].[Employee] as e 
on p.BusinessEntityID = e.BusinessEntityID

--14.   Pubs - List a titles prior year sales, define the current year as the max year in the sales (use a subquery)
use pubs
select title, sum(qty*price) as Total_Sales
from titles, sales 
where titles.title_id in (select title_id from sales where ord_date <= dateadd(year, -1, getdate()))
group by titles.title
