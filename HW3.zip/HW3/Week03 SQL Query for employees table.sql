use Maitri


/*Created: 1/28/2019
Modified: 1/28/2019
Model: Week3 SSIS
Database: MS SQL Server 2016
*/


-- Create tables section -------------------------------------------------

-- Table Male_employees

CREATE TABLE [Male_employees]
(
 [FirstName] Nvarchar(50) NOT NULL,
 [LastName] Nvarchar(50) NOT NULL,
 [Domain] Nvarchar(50) NOT NULL,
 [Login] Nvarchar(50) NOT NULL
)
go

-- Table Female_employees

CREATE TABLE [Female_employees]
(
 [FirstName] Nvarchar(50) NOT NULL,
 [LastName] Nvarchar(50) NOT NULL,
 [Domain] Nvarchar(50) NOT NULL,
 [Login] Nvarchar(50) NOT NULL
)
go

