Use pubs
--6. Show the sql to find all the titles with more than one author.

select t.title_id, t.title, count(*) as number_of_authors
from [pubs].[dbo].[titles] as t
left join[pubs].[dbo].[titleauthor] as a
on a.title_id = t.title_id 
group by t.title_id, t.title
having count(*) > 1


--7. Show the sql to show all the authors with more than one book

select a.au_id, CONCAT(a.au_fname, ' ', a.au_lname) AS "Author_name", count(*) as number_of_books
from [pubs].[dbo].[authors] as a
left join [pubs].[dbo].[titleauthor] as t
on a.au_id = t.au_id 
group by a.au_id, CONCAT(a.au_fname, ' ', a.au_lname)
having count(*) > 1


--8. Show the sql to show the publishers with no titles
select p.pub_id, p.pub_name, t.title_id
from[pubs].[dbo].[publishers] as p 
left join [pubs].[dbo].[titles] as t
on p.pub_id = t.pub_id
where p.pub_id not in 
      (select p.pub_id from publishers as p 
	   left join titles as t on p.pub_id = t.pub_id 
	   where title_id != 'NULL')

