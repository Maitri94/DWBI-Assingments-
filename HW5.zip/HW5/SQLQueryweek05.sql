-- Table State

CREATE TABLE [State]
(
 [SPK] Int IDENTITY(1,1) ,
 [StateAbbreviation] Nvarchar(10) NOT NULL,
 [StateName] Nvarchar(50) ,
 [StateFIPS] Nvarchar(50) 
)
go

-- Add keys for table State

ALTER TABLE [State] ADD CONSTRAINT [Key11] PRIMARY KEY ([StateAbbreviation])
go

-- Table County

CREATE TABLE [County]
(
 [SPK] Int IDENTITY(1,1) ,
 [CountyName] Nvarchar(50) ,
 [FIPS] Nvarchar(50) ,
 [StateAbbreviation] Nvarchar(10) NOT NULL
)
go

-- Add keys for table County

ALTER TABLE [County] ADD CONSTRAINT [Key22] PRIMARY KEY ([StateAbbreviation])
go

-- Table Zip

CREATE TABLE [Zip]
(
 [SPK] Int IDENTITY(1,1) ,
 [Zip] Nvarchar(50) ,
 [town] Nvarchar(50) ,
 [StateAbbreviation] Nvarchar(10) NOT NULL
)
go

-- Add keys for table Zip

ALTER TABLE [Zip] ADD CONSTRAINT [Key33] PRIMARY KEY ([StateAbbreviation])
go

-- Create foreign keys (relationships) section ------------------------------------------------- 


ALTER TABLE [County] ADD CONSTRAINT [Relationship11] FOREIGN KEY ([StateAbbreviation]) REFERENCES [State] ([StateAbbreviation]) ON UPDATE NO ACTION ON DELETE NO ACTION
go


ALTER TABLE [Zip] ADD CONSTRAINT [Relationship21] FOREIGN KEY ([StateAbbreviation]) REFERENCES [State] ([StateAbbreviation]) ON UPDATE NO ACTION ON DELETE NO ACTION
go









